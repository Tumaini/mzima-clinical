
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  06/22/2013 03:39:51
 * 
 */
public class McdDBConstants {

    public final static String getHivByIdQueryName = "getHivById";

}
