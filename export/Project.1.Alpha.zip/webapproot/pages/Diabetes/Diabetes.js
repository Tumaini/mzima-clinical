dojo.declare("Diabetes", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});