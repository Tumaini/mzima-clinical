dojo.declare("General", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});