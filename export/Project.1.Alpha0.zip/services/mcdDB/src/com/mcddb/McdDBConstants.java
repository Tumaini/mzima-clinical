
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  06/22/2013 16:07:29
 * 
 */
public class McdDBConstants {

    public final static String getCvdByIdQueryName = "getCvdById";

}
