
package com.mcddb.data;



/**
 *  mcdDB.Hypertension
 *  06/22/2013 16:05:14
 * 
 */
public class Hypertension {

    private Integer id;
    private String wanttoknowresults;
    private Double avgsystolicbloodpressure;
    private String knownhypertensive;
    private String intreatment;
    private String symptoms;
    private String physicalexam;
    private String referral;
    private String serolinknumber;
    private Double avgdiastolicbloodpressure;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getWanttoknowresults() {
        return wanttoknowresults;
    }

    public void setWanttoknowresults(String wanttoknowresults) {
        this.wanttoknowresults = wanttoknowresults;
    }

    public Double getAvgsystolicbloodpressure() {
        return avgsystolicbloodpressure;
    }

    public void setAvgsystolicbloodpressure(Double avgsystolicbloodpressure) {
        this.avgsystolicbloodpressure = avgsystolicbloodpressure;
    }

    public String getKnownhypertensive() {
        return knownhypertensive;
    }

    public void setKnownhypertensive(String knownhypertensive) {
        this.knownhypertensive = knownhypertensive;
    }

    public String getIntreatment() {
        return intreatment;
    }

    public void setIntreatment(String intreatment) {
        this.intreatment = intreatment;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getPhysicalexam() {
        return physicalexam;
    }

    public void setPhysicalexam(String physicalexam) {
        this.physicalexam = physicalexam;
    }

    public String getReferral() {
        return referral;
    }

    public void setReferral(String referral) {
        this.referral = referral;
    }

    public String getSerolinknumber() {
        return serolinknumber;
    }

    public void setSerolinknumber(String serolinknumber) {
        this.serolinknumber = serolinknumber;
    }

    public Double getAvgdiastolicbloodpressure() {
        return avgdiastolicbloodpressure;
    }

    public void setAvgdiastolicbloodpressure(Double avgdiastolicbloodpressure) {
        this.avgdiastolicbloodpressure = avgdiastolicbloodpressure;
    }

}
