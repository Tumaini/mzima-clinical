dojo.declare("Diabetes", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	checkboxSet1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
	},
	_end: 0
});