dojo.declare("Hypertension", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});