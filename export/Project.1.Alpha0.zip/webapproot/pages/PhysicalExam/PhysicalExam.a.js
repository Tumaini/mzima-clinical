dojo.declare("PhysicalExam", wm.Page, {
"preferredDevice": "desktop",
start: function() {
},
_end: 0
});

PhysicalExam.widgets = {
physicalexamLiveVariable1: ["wm.LiveVariable", {"type":"com.mcddb.data.Physicalexam"}, {}, {
liveView: ["wm.LiveView", {"dataType":"com.mcddb.data.Physicalexam","view":[{"caption":"Id","sortable":true,"dataIndex":"id","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},{"caption":"Serolinknumber","sortable":true,"dataIndex":"serolinknumber","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null},{"caption":"Headandneck","sortable":true,"dataIndex":"headandneck","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":2,"subType":null},{"caption":"Ent","sortable":true,"dataIndex":"ent","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":3,"subType":null},{"caption":"Skinandappendages","sortable":true,"dataIndex":"skinandappendages","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":4,"subType":null},{"caption":"Respiratory","sortable":true,"dataIndex":"respiratory","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":5,"subType":null},{"caption":"Cardiovascular","sortable":true,"dataIndex":"cardiovascular","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":6,"subType":null},{"caption":"Abdomen","sortable":true,"dataIndex":"abdomen","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":7,"subType":null},{"caption":"Cns","sortable":true,"dataIndex":"cns","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":8,"subType":null},{"caption":"Limbsandmusculoskeletal","sortable":true,"dataIndex":"limbsandmusculoskeletal","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":9,"subType":null}]}, {}]
}],
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
CLINICAL: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
ProjectMain: ["wm.Panel", {"height":"100%","horizontalAlign":"center","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
panelCenter: ["wm.Panel", {"height":"100%","horizontalAlign":"left","minHeight":600,"verticalAlign":"top","width":"900px"}, {}, {
panelHeader: ["wm.HeaderContentPanel", {"height":"65px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"0,10,0,10","verticalAlign":"middle","width":"100%"}, {}, {
picture1: ["wm.Picture", {"height":"50px","source":"lib/wm/base/widget/themes/default/images/wmLogo.png","width":"62px"}, {}],
label2: ["wm.Label", {"caption":"MZIMA CLINICAL DATA","height":"35px","padding":"4","width":"100%"}, {}],
panel10: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"middle","width":"300px"}, {}, {
panel15: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"middle","width":"100%"}, {}, {
text1: ["wm.Text", {"dataValue":undefined,"displayValue":"","placeHolder":"Search","resetButton":true,"width":"100%"}, {}],
picture5: ["wm.Picture", {"height":"16px","source":"lib/images/silkIcons/zoom.png","width":"16px"}, {}]
}]
}],
logoutButton: ["wm.Button", {"caption":"Logout","margin":"4"}, {"onclick":"varTemplateLogout"}]
}],
panel2: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
dojoMenu1: ["wm.DojoMenu", {"_classes":{"domNode":["ClickableDojoMenu"]},"fullStructure":[{"label":"GENERAL","separator":undefined,"defaultLabel":"GENERAL","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"HIV","separator":undefined,"defaultLabel":"HIV","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"TB","separator":undefined,"defaultLabel":"TB","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"DIABETES","separator":undefined,"defaultLabel":"DIABETES","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"HYPERTENSION","separator":undefined,"defaultLabel":"HYPERTENSION","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"CVD'S","separator":undefined,"defaultLabel":"CVD'S","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"CERVICAL CANCER","separator":undefined,"defaultLabel":"CERVICAL CANCER","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"MORE","separator":undefined,"defaultLabel":"MORE","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[{"label":"PHYSICAL EXAM","separator":undefined,"defaultLabel":"PHYSICAL EXAM","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"PHARMACOVIGILANCE","separator":undefined,"defaultLabel":"PHARMACOVIGILANCE","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"REFERRAL","separator":undefined,"defaultLabel":"REFERRAL","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}]}],"localizationStructure":{},"transparent":false}, {}]
}],
panelContent: ["wm.MainContentPanel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
physicalexamLivePanel1: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"Physicalexam_List","targetId":null,"targetProperty":"gridLayer"}, {}],
wire1: ["wm.Wire", {"source":"Edit_Physicalexam","targetId":null,"targetProperty":"detailsLayer"}, {}],
wire2: ["wm.Wire", {"source":"physicalexamLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
wire3: ["wm.Wire", {"source":"physicalexamDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
wire4: ["wm.Wire", {"source":"physicalexamSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
}],
physicalexamLayers: ["wm.BreadcrumbLayers", {}, {}, {
Physicalexam_List: ["wm.Layer", {"borderColor":"","caption":"Physicalexam List","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {"onShow":"physicalexamDojoGrid.deselectAll"}, {
physicalexamDojoGrid: ["wm.DojoGrid", {"columns":[{"show":true,"field":"id","title":"Id","width":"80px","displayType":"Number","align":"right","formatFunc":""},{"show":true,"field":"serolinknumber","title":"Serolinknumber","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"headandneck","title":"Headandneck","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"ent","title":"Ent","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"skinandappendages","title":"Skinandappendages","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"respiratory","title":"Respiratory","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"cardiovascular","title":"Cardiovascular","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"abdomen","title":"Abdomen","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"cns","title":"Cns","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"limbsandmusculoskeletal","title":"Limbsandmusculoskeletal","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":false,"field":"PHONE COLUMN","title":"-","width":"100%","align":"left","expression":"\"<div class='MobileRowTitle'>Id: \" + ${id} + \"</div>\"\n+ \"<div class='MobileRow'>Serolinknumber: \" + ${serolinknumber} + \"</div>\"\n+ \"<div class='MobileRow'>Headandneck: \" + ${headandneck} + \"</div>\"\n+ \"<div class='MobileRow'>Ent: \" + ${ent} + \"</div>\"\n+ \"<div class='MobileRow'>Skinandappendages: \" + ${skinandappendages} + \"</div>\"\n+ \"<div class='MobileRow'>Respiratory: \" + ${respiratory} + \"</div>\"\n+ \"<div class='MobileRow'>Cardiovascular: \" + ${cardiovascular} + \"</div>\"\n+ \"<div class='MobileRow'>Abdomen: \" + ${abdomen} + \"</div>\"\n+ \"<div class='MobileRow'>Cns: \" + ${cns} + \"</div>\"\n+ \"<div class='MobileRow'>Limbsandmusculoskeletal: \" + ${limbsandmusculoskeletal} + \"</div>\"\n","mobileColumn":true}],"dsType":"com.mcddb.data.Physicalexam","height":"100%","margin":"4"}, {"onSelect":"physicalexamLivePanel1.popupLivePanelEdit"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"physicalexamLiveVariable1","targetProperty":"dataSet"}, {}]
}]
}],
physicalexamGridButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","verticalAlign":"top","width":"100%"}, {}, {
physicalexamNewButton: ["wm.Button", {"caption":"New","margin":"4"}, {"onclick":"physicalexamLivePanel1.popupLivePanelInsert"}]
}]
}],
Edit_Physicalexam: ["wm.Layer", {"autoScroll":true,"borderColor":"","caption":"Edit Physicalexam","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
physicalexamLiveForm1: ["wm.LiveForm", {"alwaysPopulateEditors":true,"height":"100%","horizontalAlign":"left","liveEditing":false,"margin":"4","verticalAlign":"top"}, {"onSuccess":"physicalexamLivePanel1.popupLiveFormSuccess"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"physicalexamDojoGrid.selectedItem","targetProperty":"dataSet"}, {}]
}],
idEditor1: ["wm.Number", {"caption":"Id","captionSize":"140px","changeOnKey":true,"dataValue":0,"desktopHeight":"26px","emptyValue":"zero","formField":"id","height":"35px","required":true,"showing":false,"width":"100%"}, {}],
serolinknumberEditor1: ["wm.Text", {"caption":"Sero Link Number","captionSize":"140px","changeOnKey":true,"dataValue":"","desktopHeight":"26px","emptyValue":"emptyString","formField":"serolinknumber","height":"35px","required":true,"width":"100%"}, {}],
largeTextArea1: ["wm.LargeTextArea", {"caption":"Head and Neck","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"headandneck","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea2: ["wm.LargeTextArea", {"caption":"Ear Nose and Throat","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"ent","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea3: ["wm.LargeTextArea", {"caption":"Skin and Appendages","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"skinandappendages","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea4: ["wm.LargeTextArea", {"caption":"Respiratory","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"respiratory","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea5: ["wm.LargeTextArea", {"caption":"Cardiovascular","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"cardiovascular","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea6: ["wm.LargeTextArea", {"caption":"Abdomen","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"abdomen","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea7: ["wm.LargeTextArea", {"caption":"CNS","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"cns","height":"48px","required":true,"width":"100%"}, {}],
largeTextArea8: ["wm.LargeTextArea", {"caption":"Limbs and Musculoskeletal","captionAlign":"right","captionPosition":"left","captionSize":"140px","dataValue":"","desktopHeight":"48px","emptyValue":"emptyString","formField":"limbsandmusculoskeletal","height":"48px","required":true,"width":"100%"}, {}]
}],
physicalexamFormButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","verticalAlign":"top","width":"100%"}, {}, {
physicalexamSaveButton: ["wm.Button", {"caption":"Save","margin":"4"}, {"onclick":"physicalexamLiveForm1.saveDataIfValid"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"${physicalexamLiveForm1.invalid} || !${physicalexamLiveForm1.isDirty}","targetId":null,"targetProperty":"disabled"}, {}]
}]
}],
physicalexamCancelButton: ["wm.Button", {"caption":"Cancel","margin":"4"}, {"onclick":"Physicalexam_List"}],
physicalexamDeleteButton: ["wm.Button", {"caption":"Delete","margin":"4"}, {"onclick":"physicalexamLiveForm1.deleteData"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"physicalexamDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
}]
}]
}]
}]
}]
}]
}],
panelFooter: ["wm.HeaderContentPanel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
picture2: ["wm.Picture", {"height":"100%","source":"lib/wm/base/widget/themes/default/images/wmSmallLogo.png","width":"24px"}, {}],
label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"caption":"Innovations for Health","height":"100%","padding":"4"}, {}],
edFooterLabel: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"align":"right","caption":"Copyright 2013 Ifakara Health Institute","height":"100%","padding":"4","width":"100%"}, {}]
}]
}]
}]
}]
}]
};

PhysicalExam.prototype._cssText = '';
PhysicalExam.prototype._htmlText = '';