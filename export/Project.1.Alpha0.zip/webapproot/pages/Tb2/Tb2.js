dojo.declare("Tb2", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});