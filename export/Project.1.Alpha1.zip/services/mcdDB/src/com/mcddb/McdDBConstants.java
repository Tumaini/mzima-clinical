
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  06/24/2013 23:19:28
 * 
 */
public class McdDBConstants {

    public final static String getSideeffectsByIdQueryName = "getSideeffectsById";

}
