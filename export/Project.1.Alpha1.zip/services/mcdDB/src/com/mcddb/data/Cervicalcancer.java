
package com.mcddb.data;



/**
 *  mcdDB.Cervicalcancer
 *  06/24/2013 22:25:54
 * 
 */
public class Cervicalcancer {

    private Integer id;
    private String knownpatient;
    private String symptoms;
    private String serolinknumber;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getKnownpatient() {
        return knownpatient;
    }

    public void setKnownpatient(String knownpatient) {
        this.knownpatient = knownpatient;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public void setSymptoms(String symptoms) {
        this.symptoms = symptoms;
    }

    public String getSerolinknumber() {
        return serolinknumber;
    }

    public void setSerolinknumber(String serolinknumber) {
        this.serolinknumber = serolinknumber;
    }

}
