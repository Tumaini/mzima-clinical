
package com.mcddb.data;



/**
 *  mcdDB.SideEffectOutcomes
 *  06/24/2013 22:25:54
 * 
 */
public class SideEffectOutcomes {

    private Integer id;
    private Integer participantno;
    private String outcome;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParticipantno() {
        return participantno;
    }

    public void setParticipantno(Integer participantno) {
        this.participantno = participantno;
    }

    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

}
