dojo.declare("CervicalCancer", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});