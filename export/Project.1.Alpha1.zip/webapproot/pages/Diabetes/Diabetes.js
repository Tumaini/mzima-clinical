dojo.declare("Diabetes", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	checkboxSet1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
	},
	diabetesNewButtonClick1: function(inSender) {
		try {
            this.diabetesLiveForm1.beginDataInsert();
            var patientId = app.participantVar.getDataValue();
            this.text2.setDataValue(patientId);
            this.text2.setDisabled(true);

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
	},
	_end: 0
});