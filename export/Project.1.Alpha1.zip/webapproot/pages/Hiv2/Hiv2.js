dojo.declare("Hiv2", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	hivNewButtonClick1: function(inSender) {
		try {
            this.hivLiveForm1.beginDataInsert();
            var patientId = app.participantVar.getValue("dataValue");
            this.serolinknumberEditor1.setDataValue(patientId);
            this.serolinknumberEditor1.setDisabled(true);

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
	},
	_end: 0
});