dojo.declare("Hypertension", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	hypertensionNewButtonClick1: function(inSender) {
		try {
            this.hypertensionLiveForm1.beginDataInsert();
            var patientId = app.participantVar.getDataValue();
            this.serolinknumberEditor1.setDataValue(patientId);
            this.serolinknumberEditor1.setDisabled(true);

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
	},
	_end: 0
});