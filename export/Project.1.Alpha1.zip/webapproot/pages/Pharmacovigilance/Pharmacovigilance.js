dojo.declare("Pharmacovigilance", wm.Page, {
    "preferredDevice": "desktop",
    start: function() {

    },

    largeTextArea1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            var inputStr = this.largeTextArea1.getDataValue();
            this.largeTextArea1.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
    },
    radioSet3Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            if (this.radioSet3.getDataValue() == 'YES') {
                this.designableDialog1.show();
            }
        } catch (e) {}
    },
    largeTextArea2Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            var inputStr = this.largeTextArea2.getDataValue();
            this.largeTextArea2.setDataValue(inputStr.toUpperCase());
            
        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
    },
    checkboxSet1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            if (this.checkboxSet1.getDataValue() == 'OTHERS') {
                this.designableDialog2.show();
            }
        } catch (e) {}
    },
    _end: 0
});