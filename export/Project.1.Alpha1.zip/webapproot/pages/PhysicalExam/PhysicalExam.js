dojo.declare("PhysicalExam", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	_end: 0
});