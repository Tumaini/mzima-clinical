dojo.declare("Tb2", wm.Page, {
"preferredDevice": "desktop",
start: function() {
},
tbNewButtonClick1: function(inSender) {
try {
this.tbLiveForm1.beginDataInsert();
var patientId = app.participantVar.getValue("dataValue");
this.seroLinkNumberEditor1.setDataValue(patientId);
this.seroLinkNumberEditor1.setDisabled(true);
} catch (e) {
console.error('ERROR IN newButton1Click: ' + e);
}
},
_end: 0
});

Tb2.widgets = {
tbLiveVariable1: ["wm.LiveVariable", {"type":"com.mcddb.data.Tb"}, {}, {
liveView: ["wm.LiveView", {"dataType":"com.mcddb.data.Tb","view":[{"caption":"Id","sortable":true,"dataIndex":"id","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},{"caption":"Knowntbpatient","sortable":true,"dataIndex":"knowntbpatient","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null},{"caption":"Ontbtreatment","sortable":true,"dataIndex":"ontbtreatment","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":2,"subType":null},{"caption":"Treatedlast12months","sortable":true,"dataIndex":"treatedlast12months","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":3,"subType":null},{"caption":"Symptoms","sortable":true,"dataIndex":"symptoms","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":4,"subType":null},{"caption":"Physicalexam","sortable":true,"dataIndex":"physicalexam","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":5,"subType":null},{"caption":"Participanttobereferred","sortable":true,"dataIndex":"participanttobereferred","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":6,"subType":null},{"caption":"Serolinknumber","sortable":true,"dataIndex":"serolinknumber","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":7,"subType":null}]}, {}]
}],
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
CLINICAL: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
ProjectMain: ["wm.Panel", {"height":"100%","horizontalAlign":"center","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
panelCenter: ["wm.Panel", {"height":"100%","horizontalAlign":"left","minHeight":600,"verticalAlign":"top","width":"900px"}, {}, {
panelHeader: ["wm.HeaderContentPanel", {"height":"65px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"0,10,0,10","verticalAlign":"middle","width":"100%"}, {}, {
picture1: ["wm.Picture", {"height":"50px","source":"lib/wm/base/widget/themes/default/images/wmLogo.png","width":"62px"}, {}],
label2: ["wm.Label", {"caption":"MZIMA CLINICAL DATA","height":"35px","padding":"4","width":"100%"}, {}],
panel10: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"middle","width":"300px"}, {}, {
panel15: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"middle","width":"100%"}, {}, {
text1: ["wm.Text", {"dataValue":undefined,"displayValue":"","placeHolder":"Search","resetButton":true,"width":"100%"}, {}],
picture5: ["wm.Picture", {"height":"16px","source":"lib/images/silkIcons/zoom.png","width":"16px"}, {}]
}]
}],
logoutButton: ["wm.Button", {"caption":"Logout","margin":"4"}, {"onclick":"varTemplateLogout"}]
}],
panel2: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
dojoMenu1: ["wm.DojoMenu", {"_classes":{"domNode":["ClickableDojoMenu"]},"fullStructure":[{"label":"GENERAL","separator":undefined,"defaultLabel":"GENERAL","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"HIV","separator":undefined,"defaultLabel":"HIV","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"TB","separator":undefined,"defaultLabel":"TB","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"DIABETES","separator":undefined,"defaultLabel":"DIABETES","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"HYPERTENSION","separator":undefined,"defaultLabel":"HYPERTENSION","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"CVD'S","separator":undefined,"defaultLabel":"CVD'S","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"CERVICAL CANCER","separator":undefined,"defaultLabel":"CERVICAL CANCER","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"MORE","separator":undefined,"defaultLabel":"MORE","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[{"label":"PHYSICAL EXAM","separator":undefined,"defaultLabel":"PHYSICAL EXAM","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"PHARMACOVIGILANCE","separator":undefined,"defaultLabel":"PHARMACOVIGILANCE","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]},{"label":"REFERRAL","separator":undefined,"defaultLabel":"REFERRAL","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[]}]}],"localizationStructure":{},"transparent":false}, {}]
}],
panelContent: ["wm.MainContentPanel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
tbLivePanel1: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"Tb_List","targetId":null,"targetProperty":"gridLayer"}, {}],
wire1: ["wm.Wire", {"source":"Edit_Tb","targetId":null,"targetProperty":"detailsLayer"}, {}],
wire2: ["wm.Wire", {"source":"tbLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
wire3: ["wm.Wire", {"source":"tbDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
wire4: ["wm.Wire", {"source":"tbSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
}],
tbLayers: ["wm.BreadcrumbLayers", {}, {}, {
Tb_List: ["wm.Layer", {"borderColor":"","caption":"Tb List","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {"onShow":"tbDojoGrid.deselectAll"}, {
tbDojoGrid: ["wm.DojoGrid", {"columns":[{"show":true,"field":"id","title":"Id","width":"80px","displayType":"Number","align":"right","formatFunc":""},{"show":true,"field":"knowntbpatient","title":"Knowntbpatient","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"ontbtreatment","title":"Ontbtreatment","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"treatedlast12months","title":"Treatedlast12months","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"symptoms","title":"Symptoms","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"physicalexam","title":"Physicalexam","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"participanttobereferred","title":"Participanttobereferred","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":true,"field":"serolinknumber","title":"Serolinknumber","width":"100%","displayType":"Text","align":"left","formatFunc":""},{"show":false,"field":"PHONE COLUMN","title":"-","width":"100%","align":"left","expression":"\"<div class='MobileRowTitle'>Id: \" + ${id} + \"</div>\"\n+ \"<div class='MobileRow'>Knowntbpatient: \" + ${knowntbpatient} + \"</div>\"\n+ \"<div class='MobileRow'>Ontbtreatment: \" + ${ontbtreatment} + \"</div>\"\n+ \"<div class='MobileRow'>Treatedlast12months: \" + ${treatedlast12months} + \"</div>\"\n+ \"<div class='MobileRow'>Symptoms: \" + ${symptoms} + \"</div>\"\n+ \"<div class='MobileRow'>Physicalexam: \" + ${physicalexam} + \"</div>\"\n+ \"<div class='MobileRow'>Participanttobereferred: \" + ${participanttobereferred} + \"</div>\"\n+ \"<div class='MobileRow'>Serolinknumber: \" + ${serolinknumber} + \"</div>\"\n","mobileColumn":true}],"dsType":"com.mcddb.data.Tb","height":"100%","margin":"4"}, {"onSelect":"tbLivePanel1.popupLivePanelEdit"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tbLiveVariable1","targetProperty":"dataSet"}, {}]
}]
}],
tbGridButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","verticalAlign":"top","width":"100%"}, {}, {
tbNewButton: ["wm.Button", {"caption":"New","margin":"4"}, {"onclick":"tbLivePanel1.popupLivePanelInsert","onclick1":"tbNewButtonClick1"}]
}]
}],
Edit_Tb: ["wm.Layer", {"autoScroll":true,"borderColor":"","caption":"Edit Tb","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
tbLiveForm1: ["wm.LiveForm", {"alwaysPopulateEditors":true,"height":"100%","horizontalAlign":"left","liveEditing":false,"margin":"4","verticalAlign":"top"}, {"onSuccess":"tbLivePanel1.popupLiveFormSuccess"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"tbDojoGrid.selectedItem","targetProperty":"dataSet"}, {}]
}],
idEditor1: ["wm.Number", {"caption":"Id","captionSize":"140px","changeOnKey":true,"dataValue":0,"desktopHeight":"26px","emptyValue":"zero","formField":"id","height":"26px","required":true,"showing":false,"width":"100%"}, {}],
seroLinkNumberEditor1: ["wm.Text", {"caption":"Sero Link Number","captionSize":"140px","changeOnKey":true,"dataValue":"","desktopHeight":"26px","emptyValue":"emptyString","formField":"serolinknumber","height":"26px","required":true,"width":"100%"}, {}],
radioSet1: ["wm.RadioSet", {"caption":"Is participant a known current TB patient?","captionSize":"140px","dataField":"dataValue","dataValue":undefined,"desktopHeight":"56px","displayField":"dataValue","formField":"knowntbpatient","height":"56px","options":"YES,NO","required":true,"width":"100%"}, {}],
radioSet2: ["wm.RadioSet", {"caption":"Is the participant on TB treatment?","captionSize":"140px","dataField":"dataValue","dataValue":undefined,"desktopHeight":"56px","displayField":"dataValue","formField":"ontbtreatment","height":"56px","options":"YES,NO","required":true,"width":"100%"}, {}],
radioSet3: ["wm.RadioSet", {"caption":"Has the participant been treated for TB in the past 12 months?","captionSize":"140px","dataField":"dataValue","dataValue":undefined,"desktopHeight":"57px","displayField":"dataValue","formField":"treatedlast12months","height":"57px","options":"YES,NO","required":true,"width":"100%"}, {}],
checkboxSet1: ["wm.CheckboxSet", {"caption":"Is participant experiencing any of the following?","captionSize":"140px","dataField":"dataValue","desktopHeight":"134px","displayField":"dataValue","formField":"symptoms","height":"134px","options":"Cough ≥ 2 weeks,Fever ≥ 2 weeks,Excessive night sweats ≥ 2 weeks,Weight loss ≥ 3Kgs,Haemoptysis","required":true,"width":"100%"}, {}],
radioSet5: ["wm.RadioSet", {"caption":"Is physical exam to be performed?","captionSize":"140px","dataField":"dataValue","dataValue":undefined,"desktopHeight":"56px","displayField":"dataValue","formField":"physicalexam","height":"56px","options":"YES,NO","required":true,"width":"100%"}, {}],
radioSet6: ["wm.RadioSet", {"caption":"Participant to be referred","captionSize":"140px","dataField":"dataValue","dataValue":undefined,"desktopHeight":"56px","displayField":"dataValue","formField":"participanttobereferred","height":"56px","options":"YES,NO","required":true,"width":"100%"}, {}]
}],
tbFormButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","verticalAlign":"top","width":"100%"}, {}, {
tbSaveButton: ["wm.Button", {"caption":"Save","margin":"4"}, {"onclick":"tbLiveForm1.saveDataIfValid","onclick1":"app.toDiabetes"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"${tbLiveForm1.invalid} || !${tbLiveForm1.isDirty}","targetId":null,"targetProperty":"disabled"}, {}]
}]
}],
tbCancelButton: ["wm.Button", {"caption":"Cancel","margin":"4"}, {"onclick":"Tb_List"}],
tbDeleteButton: ["wm.Button", {"caption":"Delete","margin":"4"}, {"onclick":"tbLiveForm1.deleteData"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"tbDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
}]
}]
}]
}]
}]
}]
}],
panelFooter: ["wm.HeaderContentPanel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
picture2: ["wm.Picture", {"height":"100%","source":"lib/wm/base/widget/themes/default/images/wmSmallLogo.png","width":"24px"}, {}],
label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"caption":"Innovations for Health","height":"100%","padding":"4"}, {}],
edFooterLabel: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"align":"right","caption":"Copyright 2013 Ifakara Health Institute","height":"100%","padding":"4","width":"100%"}, {}]
}]
}]
}]
}]
}]
};

Tb2.prototype._cssText = '';
Tb2.prototype._htmlText = '';