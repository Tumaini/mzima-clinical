dojo.declare("Tb2", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	tbNewButtonClick1: function(inSender) {
		try {
            this.tbLiveForm1.beginDataInsert();
            var patientId = app.participantVar.getValue("dataValue");
            this.seroLinkNumberEditor1.setDataValue(patientId);
            this.seroLinkNumberEditor1.setDisabled(true);

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
	},
	_end: 0
});