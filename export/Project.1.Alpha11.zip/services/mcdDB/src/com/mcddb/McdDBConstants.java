
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  07/01/2013 17:42:51
 * 
 */
public class McdDBConstants {

    public final static String getSideeffectsByIdQueryName = "getSideeffectsById";

}
