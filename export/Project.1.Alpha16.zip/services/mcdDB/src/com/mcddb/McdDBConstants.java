
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  07/03/2013 16:37:03
 * 
 */
public class McdDBConstants {

    public final static String getSideeffectsByIdQueryName = "getSideeffectsById";

}
