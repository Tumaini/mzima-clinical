
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  06/27/2013 00:39:19
 * 
 */
public class McdDBConstants {

    public final static String getSideeffectsByIdQueryName = "getSideeffectsById";

}
