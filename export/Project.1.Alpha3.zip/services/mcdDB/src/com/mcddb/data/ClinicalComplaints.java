
package com.mcddb.data;



/**
 *  mcdDB.ClinicalComplaints
 *  06/27/2013 00:38:41
 * 
 */
public class ClinicalComplaints {

    private Integer id;
    private Integer participantno;
    private String complaint;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParticipantno() {
        return participantno;
    }

    public void setParticipantno(Integer participantno) {
        this.participantno = participantno;
    }

    public String getComplaint() {
        return complaint;
    }

    public void setComplaint(String complaint) {
        this.complaint = complaint;
    }

}
