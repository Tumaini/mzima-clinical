dojo.declare("PhysicalExam", wm.Page, {
"preferredDevice": "desktop",
start: function() {
},
physicalexamNewButtonClick1: function(inSender) {
try {
this.physicalexamLiveForm1.beginDataInsert();
var patientId = app.participantVar.getValue("dataValue");
this.serolinknumberEditor1.setDataValue(patientId);
this.serolinknumberEditor1.setDisabled(true);
} catch (e) {
console.error('ERROR IN newButton1Click: ' + e);
}
},
largeTextArea1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea1.getDataValue();
this.largeTextArea1.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea2Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea2.getDataValue();
this.largeTextArea2.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea3Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea3.getDataValue();
this.largeTextArea3.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea4Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea4.getDataValue();
this.largeTextArea4.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea5Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea5.getDataValue();
this.largeTextArea5.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea6Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea6.getDataValue();
this.largeTextArea6.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea7Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea7.getDataValue();
this.largeTextArea7.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
largeTextArea8Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
try {
var inputStr = this.largeTextArea8.getDataValue();
this.largeTextArea8.setDataValue(inputStr.toUpperCase());
} catch (e) {
console.error('ERROR IN largeTextArea1Change: ' + e);
}
},
_end: 0
});

PhysicalExam.widgets = {
physicalexamLiveVariable1: ["wm.LiveVariable", {"type":"com.mcddb.data.Physicalexam"}, {}, {
liveView: ["wm.LiveView", {"dataType":"com.mcddb.data.Physicalexam","view":[{"caption":"Id","sortable":true,"dataIndex":"id","type":"java.lang.Integer","displayType":"Number","required":true,"readonly":true,"includeLists":true,"includeForms":true,"order":0,"subType":null},{"caption":"Serolinknumber","sortable":true,"dataIndex":"serolinknumber","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":1,"subType":null},{"caption":"Headandneck","sortable":true,"dataIndex":"headandneck","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":2,"subType":null},{"caption":"Ent","sortable":true,"dataIndex":"ent","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":3,"subType":null},{"caption":"Skinandappendages","sortable":true,"dataIndex":"skinandappendages","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":4,"subType":null},{"caption":"Respiratory","sortable":true,"dataIndex":"respiratory","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":5,"subType":null},{"caption":"Cardiovascular","sortable":true,"dataIndex":"cardiovascular","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":6,"subType":null},{"caption":"Abdomen","sortable":true,"dataIndex":"abdomen","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":7,"subType":null},{"caption":"Cns","sortable":true,"dataIndex":"cns","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":8,"subType":null},{"caption":"Limbsandmusculoskeletal","sortable":true,"dataIndex":"limbsandmusculoskeletal","type":"java.lang.String","displayType":"Text","required":false,"readonly":false,"includeLists":true,"includeForms":true,"order":9,"subType":null}]}, {}]
}],
layoutBox1: ["wm.Layout", {"horizontalAlign":"left","verticalAlign":"top"}, {}, {
CLINICAL: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"top","width":"100%"}, {}, {
ProjectMain: ["wm.Panel", {"height":"100%","horizontalAlign":"center","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
panelCenter: ["wm.Panel", {"height":"100%","horizontalAlign":"left","minHeight":600,"verticalAlign":"top","width":"900px"}, {}, {
panelHeader: ["wm.HeaderContentPanel", {"height":"65px","horizontalAlign":"left","layoutKind":"left-to-right","padding":"0,10,0,10","verticalAlign":"middle","width":"100%"}, {}, {
picture1: ["wm.Picture", {"height":"50px","source":"lib/wm/base/widget/themes/default/images/wmLogo.png","width":"62px"}, {}],
label2: ["wm.Label", {"caption":"MZIMA CLINICAL DATA","height":"35px","padding":"4","width":"100%"}, {}],
panel10: ["wm.Panel", {"height":"100%","horizontalAlign":"left","verticalAlign":"middle","width":"300px"}, {}, {
panel15: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"middle","width":"100%"}, {}, {
text1: ["wm.Text", {"dataValue":undefined,"displayValue":"","placeHolder":"Search","resetButton":true,"width":"100%"}, {}],
picture5: ["wm.Picture", {"height":"16px","source":"lib/images/silkIcons/zoom.png","width":"16px"}, {}]
}]
}],
logoutButton: ["wm.Button", {"caption":"Logout","margin":"4"}, {"onclick":"varTemplateLogout"}]
}],
panel2: ["wm.Panel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
dojoMenu1: ["wm.DojoMenu", {"_classes":{"domNode":["ClickableDojoMenu"]},"fullStructure":[{"label":"GENERAL","separator":undefined,"defaultLabel":"GENERAL","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toGeneral","children":[]},{"label":"HIV","separator":undefined,"defaultLabel":"HIV","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toHIV","children":[]},{"label":"TB","separator":undefined,"defaultLabel":"TB","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toTB","children":[]},{"label":"DIABETES","separator":undefined,"defaultLabel":"DIABETES","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toDiabetes","children":[]},{"label":"HYPERTENSION","separator":undefined,"defaultLabel":"HYPERTENSION","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toHypertension","children":[]},{"label":"CVD'S","separator":undefined,"defaultLabel":"CVD'S","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toCVD","children":[]},{"label":"CERVICAL CANCER","separator":undefined,"defaultLabel":"CERVICAL CANCER","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toCancer","children":[]},{"label":"MORE","separator":undefined,"defaultLabel":"MORE","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":undefined,"children":[{"label":"PHYSICAL EXAM","separator":undefined,"defaultLabel":"PHYSICAL EXAM","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toPhysExam","children":[]},{"label":"PHARMACOVIGILANCE","separator":undefined,"defaultLabel":"PHARMACOVIGILANCE","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toPharma","children":[]},{"label":"REFERRAL","separator":undefined,"defaultLabel":"REFERRAL","iconClass":undefined,"imageList":undefined,"idInPage":undefined,"isCheckbox":false,"onClick":"app.toReferral","children":[]}]}],"localizationStructure":{},"transparent":false}, {}]
}],
label3: ["wm.Label", {"caption":">>PHYSICAL EXAM","padding":"4","styles":{"backgroundColor":"#ffffff","fontWeight":"bolder"}}, {}],
panelContent: ["wm.MainContentPanel", {"height":"100%","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
physicalexamLivePanel1: ["wm.LivePanel", {"autoScroll":false,"horizontalAlign":"left","verticalAlign":"top"}, {}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"Physicalexam_List","targetId":null,"targetProperty":"gridLayer"}, {}],
wire1: ["wm.Wire", {"source":"Edit_Physicalexam","targetId":null,"targetProperty":"detailsLayer"}, {}],
wire2: ["wm.Wire", {"source":"physicalexamLiveForm1","targetId":null,"targetProperty":"liveForm"}, {}],
wire3: ["wm.Wire", {"source":"physicalexamDojoGrid","targetId":null,"targetProperty":"dataGrid"}, {}],
wire4: ["wm.Wire", {"source":"physicalexamSaveButton","targetId":null,"targetProperty":"saveButton"}, {}]
}],
physicalexamLayers: ["wm.BreadcrumbLayers", {}, {}, {
Physicalexam_List: ["wm.Layer", {"borderColor":"","caption":"Physicalexam List","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {"onShow":"physicalexamDojoGrid.deselectAll"}, {
physicalexamDojoGrid: ["wm.DojoGrid", {"columns":[{"show":false,"field":"id","title":"Id","width":"80px","align":"right","formatFunc":"","mobileColumn":false},{"show":true,"field":"serolinknumber","title":"Sero Link Number","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"headandneck","title":"HEAD & NECK","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"ent","title":"ENT","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"skinandappendages","title":"SKIN & APPENDAGES","width":"104px","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"respiratory","title":"RESP","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"cardiovascular","title":"CARDIO","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"abdomen","title":"ABDOMEN","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"cns","title":"CNS","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":true,"field":"limbsandmusculoskeletal","title":"L&M","width":"100%","align":"left","formatFunc":"","editorProps":{"restrictValues":true},"mobileColumn":false},{"show":false,"field":"PHONE COLUMN","title":"-","width":"100%","align":"left","expression":"\"<div class='MobileRowTitle'>Sero Link Number: \" + ${serolinknumber} + \"</div>\"\n+ \"<div class='MobileRow'>HEAD & NECK: \" + ${headandneck} + \"</div>\"\n+ \"<div class='MobileRow'>ENT: \" + ${ent} + \"</div>\"\n+ \"<div class='MobileRow'>SKIN & APPENDAGES: \" + ${skinandappendages} + \"</div>\"\n+ \"<div class='MobileRow'>RESP: \" + ${respiratory} + \"</div>\"\n+ \"<div class='MobileRow'>CARDIO: \" + ${cardiovascular} + \"</div>\"\n+ \"<div class='MobileRow'>ABDOMEN: \" + ${abdomen} + \"</div>\"\n+ \"<div class='MobileRow'>CNS: \" + ${cns} + \"</div>\"\n+ \"<div class='MobileRow'>L&M: \" + ${limbsandmusculoskeletal} + \"</div>\"\n","mobileColumn":true}],"dsType":"com.mcddb.data.Physicalexam","height":"100%","margin":"4"}, {"onSelect":"physicalexamLivePanel1.popupLivePanelEdit"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"physicalexamLiveVariable1","targetProperty":"dataSet"}, {}]
}]
}],
physicalexamGridButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","verticalAlign":"top","width":"100%"}, {}, {
physicalexamNewButton: ["wm.Button", {"caption":"New","margin":"4"}, {"onclick":"physicalexamLivePanel1.popupLivePanelInsert","onclick1":"physicalexamNewButtonClick1"}]
}]
}],
Edit_Physicalexam: ["wm.Layer", {"autoScroll":true,"borderColor":"","caption":"Edit Physicalexam","horizontalAlign":"left","themeStyleType":"ContentPanel","verticalAlign":"top"}, {}, {
physicalexamLiveForm1: ["wm.LiveForm", {"alwaysPopulateEditors":true,"height":"100%","horizontalAlign":"left","liveEditing":false,"margin":"4","verticalAlign":"top"}, {"onSuccess":"physicalexamLivePanel1.popupLiveFormSuccess"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":undefined,"source":"physicalexamDojoGrid.selectedItem","targetProperty":"dataSet"}, {}]
}],
idEditor1: ["wm.Number", {"caption":"Id","captionSize":"140px","changeOnKey":true,"dataValue":0,"desktopHeight":"26px","emptyValue":"zero","formField":"id","height":"26px","required":true,"showing":false,"width":"100%"}, {}],
serolinknumberEditor1: ["wm.Text", {"caption":"Sero Link Number","captionSize":"140px","changeOnKey":true,"dataValue":"","desktopHeight":"26px","emptyValue":"emptyString","formField":"serolinknumber","height":"26px","required":true,"width":"50%"}, {}],
largeTextArea1: ["wm.LargeTextArea", {"caption":"Head and Neck","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"headandneck","height":"48px","width":"100%"}, {"onchange":"largeTextArea1Change"}],
largeTextArea2: ["wm.LargeTextArea", {"caption":"Ear Nose and Throat","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"ent","height":"48px","width":"100%"}, {"onchange":"largeTextArea2Change"}],
largeTextArea3: ["wm.LargeTextArea", {"caption":"Skin and Appendages","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"skinandappendages","height":"48px","width":"100%"}, {"onchange":"largeTextArea3Change"}],
largeTextArea4: ["wm.LargeTextArea", {"caption":"Respiratory","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"respiratory","height":"48px","width":"100%"}, {"onchange":"largeTextArea4Change"}],
largeTextArea5: ["wm.LargeTextArea", {"caption":"Cardiovascular","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"cardiovascular","height":"48px","width":"100%"}, {"onchange":"largeTextArea5Change"}],
largeTextArea6: ["wm.LargeTextArea", {"caption":"Abdomen","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"abdomen","height":"48px","width":"100%"}, {"onchange":"largeTextArea6Change"}],
largeTextArea7: ["wm.LargeTextArea", {"caption":"CNS","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"cns","height":"48px","width":"100%"}, {"onchange":"largeTextArea7Change"}],
largeTextArea8: ["wm.LargeTextArea", {"caption":"Limbs and Musculoskeletal","captionAlign":"right","captionPosition":"left","captionSize":"140px","changeOnKey":true,"dataValue":"","defaultInsert":"N/A","desktopHeight":"48px","emptyValue":"emptyString","formField":"limbsandmusculoskeletal","height":"48px","width":"100%"}, {"onchange":"largeTextArea8Change"}]
}],
physicalexamFormButtonPanel: ["wm.Panel", {"desktopHeight":"32px","enableTouchHeight":true,"height":"32px","horizontalAlign":"right","layoutKind":"left-to-right","mobileHeight":"40px","verticalAlign":"top","width":"100%"}, {}, {
physicalexamSaveButton: ["wm.Button", {"caption":"Save","margin":"4"}, {"onclick":"physicalexamLiveForm1.saveDataIfValid","onclick1":"app.toPharma"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"expression":"${physicalexamLiveForm1.invalid} || !${physicalexamLiveForm1.isDirty}","targetId":null,"targetProperty":"disabled"}, {}]
}]
}],
physicalexamCancelButton: ["wm.Button", {"caption":"Cancel","margin":"4"}, {"onclick":"Physicalexam_List"}],
physicalexamDeleteButton: ["wm.Button", {"caption":"Delete","margin":"4"}, {"onclick":"physicalexamLiveForm1.deleteData"}, {
binding: ["wm.Binding", {}, {}, {
wire: ["wm.Wire", {"source":"physicalexamDojoGrid.emptySelection","targetId":null,"targetProperty":"disabled"}, {}]
}]
}]
}]
}]
}]
}]
}],
panelFooter: ["wm.HeaderContentPanel", {"height":"24px","horizontalAlign":"left","layoutKind":"left-to-right","verticalAlign":"top","width":"100%"}, {}, {
picture2: ["wm.Picture", {"height":"100%","source":"lib/wm/base/widget/themes/default/images/wmSmallLogo.png","width":"24px"}, {}],
label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"caption":"Innovations for Health","height":"100%","padding":"4"}, {}],
edFooterLabel: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_10px"]},"align":"right","caption":"Copyright 2013 Ifakara Health Institute","height":"100%","padding":"4","width":"100%"}, {}]
}]
}]
}]
}]
}]
};

PhysicalExam.prototype._cssText = '';
PhysicalExam.prototype._htmlText = '';