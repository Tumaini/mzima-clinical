dojo.declare("Referral", wm.Page, {
    "preferredDevice": "desktop",
    start: function() {

    },


    referralSaveButtonClick: function(inSender) {
        try {
            app.toGeneral.update();
        } catch (e) {}
    },
    referralNewButtonClick1: function(inSender) {
        try {
            this.referralLiveForm1.beginDataInsert();
            var patientId = app.participantVar.getValue("dataValue");
            this.serolinknumberEditor1.setDataValue(patientId);
            this.serolinknumberEditor1.setDisabled(true);

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
    },
    _end: 0
});