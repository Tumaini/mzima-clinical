
package com.mcddb;



/**
 *  Query names for service "mcdDB"
 *  06/27/2013 13:38:59
 * 
 */
public class McdDBConstants {

    public final static String getSideeffectsByIdQueryName = "getSideeffectsById";

}
