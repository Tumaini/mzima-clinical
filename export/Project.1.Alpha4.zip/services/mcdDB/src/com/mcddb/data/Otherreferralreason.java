
package com.mcddb.data;



/**
 *  mcdDB.Otherreferralreason
 *  06/27/2013 13:37:17
 * 
 */
public class Otherreferralreason {

    private Integer id;
    private String serolinknumber;
    private String reason;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerolinknumber() {
        return serolinknumber;
    }

    public void setSerolinknumber(String serolinknumber) {
        this.serolinknumber = serolinknumber;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

}
