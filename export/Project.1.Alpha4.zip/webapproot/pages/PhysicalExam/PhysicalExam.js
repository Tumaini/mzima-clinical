dojo.declare("PhysicalExam", wm.Page, {
	"preferredDevice": "desktop",
	start: function() {
		
	},

	physicalexamNewButtonClick1: function(inSender) {
		try {
            this.physicalexamLiveForm1.beginDataInsert();
            var patientId = app.participantVar.getValue("dataValue");
            this.serolinknumberEditor1.setDataValue(patientId);
            this.serolinknumberEditor1.setDisabled(true);

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
	},
	largeTextArea1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea1.getDataValue();
            this.largeTextArea1.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea2Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea2.getDataValue();
            this.largeTextArea2.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea3Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea3.getDataValue();
            this.largeTextArea3.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea4Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea4.getDataValue();
            this.largeTextArea4.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea5Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea5.getDataValue();
            this.largeTextArea5.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea6Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea6.getDataValue();
            this.largeTextArea6.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea7Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea7.getDataValue();
            this.largeTextArea7.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	largeTextArea8Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
		try {
            var inputStr = this.largeTextArea8.getDataValue();
            this.largeTextArea8.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
	},
	_end: 0
});