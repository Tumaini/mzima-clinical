
package com.mcddb.data;



/**
 *  mcdDB.Otherreferralfacility
 *  06/27/2013 13:37:17
 * 
 */
public class Otherreferralfacility {

    private Integer id;
    private String serolinknumber;
    private String facility;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerolinknumber() {
        return serolinknumber;
    }

    public void setSerolinknumber(String serolinknumber) {
        this.serolinknumber = serolinknumber;
    }

    public String getFacility() {
        return facility;
    }

    public void setFacility(String facility) {
        this.facility = facility;
    }

}
