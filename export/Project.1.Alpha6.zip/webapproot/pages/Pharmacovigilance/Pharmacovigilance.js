dojo.declare("Pharmacovigilance", wm.Page, {
    "preferredDevice": "desktop",
    start: function() {

    },

    largeTextArea1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            var inputStr = this.largeTextArea1.getDataValue();
            this.largeTextArea1.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
    },
    radioSet3Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            if (this.radioSet3.getDataValue() == 'YES') {
                this.designableDialog1.show();
            }
        } catch (e) {}
    },
    largeTextArea2Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            var inputStr = this.largeTextArea2.getDataValue();
            this.largeTextArea2.setDataValue(inputStr.toUpperCase());

        } catch (e) {
            console.error('ERROR IN largeTextArea1Change: ' + e);
        }
    },
    checkboxSet1Change: function(inSender, inDisplayValue, inDataValue, inSetByCode) {
        try {
            if (this.checkboxSet1.getDataValue() == 'OTHERS') {
                this.designableDialog2.show();
            }
        } catch (e) {}
    },
    pharmacovigilanceNewButtonClick1: function(inSender) {
        try {
            if (app.participantVar.getValue("dataValue") !== null && app.participantVar.getValue("dataValue") !==undefined) {
                this.pharmacovigilanceLiveForm1.beginDataInsert();
                var patientId = app.participantVar.getValue("dataValue");
                this.serolinknumberEditor1.setDataValue(patientId);
                this.serolinknumberEditor1.setDisabled(true);
            }

        } catch (e) {
            console.error('ERROR IN newButton1Click: ' + e);
        }
    },
    pharmacovigilanceSaveButtonClick1: function(inSender) {
        try {
            if (app.referral.getValue("datavalue")) {
                app.toReferral.update();
            } else {
                app.toGeneral.update();
                }
        } catch (e) {}
    },
    _end: 0
});