
package com.mcddb.data;



/**
 *  mcdDB.Otherreferralreason
 *  07/01/2013 13:49:52
 * 
 */
public class Otherreferralreason {

    private Integer id;
    private String serolinknumber;
    private String reason;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSerolinknumber() {
        return serolinknumber;
    }

    public void setSerolinknumber(String serolinknumber) {
        this.serolinknumber = serolinknumber;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

}
