
package com.mcddb.data;



/**
 *  mcdDB.Referral
 *  07/01/2013 13:49:52
 * 
 */
public class Referral {

    private Integer id;
    private Integer serolinknumber;
    private String facility;
    private String reason;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getSerolinknumber() {
        return serolinknumber;
    }

    public void setSerolinknumber(Integer serolinknumber) {
        this.serolinknumber = serolinknumber;
    }

    public String getFacility() {
        return facility;
    }

    public void setFacility(String facility) {
        this.facility = facility;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

}
