
package com.mcddb.data;



/**
 *  mcdDB.SideEffectOutcomes
 *  07/01/2013 13:49:52
 * 
 */
public class SideEffectOutcomes {

    private Integer id;
    private Integer participantno;
    private String outcome;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParticipantno() {
        return participantno;
    }

    public void setParticipantno(Integer participantno) {
        this.participantno = participantno;
    }

    public String getOutcome() {
        return outcome;
    }

    public void setOutcome(String outcome) {
        this.outcome = outcome;
    }

}
