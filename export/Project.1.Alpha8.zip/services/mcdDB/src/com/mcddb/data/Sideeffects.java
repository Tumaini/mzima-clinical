
package com.mcddb.data;



/**
 *  mcdDB.Sideeffects
 *  07/01/2013 13:49:52
 * 
 */
public class Sideeffects {

    private Integer id;
    private Integer participantno;
    private String sideeffect;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParticipantno() {
        return participantno;
    }

    public void setParticipantno(Integer participantno) {
        this.participantno = participantno;
    }

    public String getSideeffect() {
        return sideeffect;
    }

    public void setSideeffect(String sideeffect) {
        this.sideeffect = sideeffect;
    }

}
